import smtplib
from airflow import DAG
from datetime import datetime,timedelta
from airflow.operators.dummy_operator import DummyOperator

default_args={
    'owner':'airflow',
    'depends_on_past':False,
    'start_date':datetime(2020,4,13),
    'retries':0

}

def send():
    try:
        x=smtplib.SMTP('pdssuni@gmail.com',587)
        x.starttls()
        x.login("pdssuni@gmail.com","acpqjbtlqtflljcy")
        subject="testing"
        body_test=" testing success"
        message="subject:{}\n\n{}".format(subject,body_test)
        x.sendmail("pdssuni@gmail.com","pdssuni@gmail.com",message)
        print("success")
    except Exception as exception:
        print(exception)
        print(failure)

dag=DAG(dag_id='email',default_args=default_args,catchup=False,schedule_interval=None)

email_testing=DummyOperator(task_id='testing',python_callable=send)

email_testing

