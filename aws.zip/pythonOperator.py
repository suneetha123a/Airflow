from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime

  
#step-2
default_args={
    'owner':'airflow',
    'depends_on_past':False,
    'start_date':datetime(2020,4,13),
    'retries':0


}

def greet():
    print("hello")

#step-3
dag=DAG(dag_id='py1',default_args=default_args,catchup=False,schedule_interval='@once')



   


task1 = PythonOperator(
    task_id="task1",
  
    python_callable=greet,
      dag=dag,
    )

task1