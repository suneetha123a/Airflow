################################################################ script-1 ###########################################################
#storing triggered s3 file path into one variable


import json
import json
from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql.functions import concat_ws

def lambda_handler(event, context):
    # Check if the event is triggered by an S3 bucket event
    if 'Records' in event and len(event['Records']) > 0:
        # Extract the S3 file path from the event
        s3_event = event['Records'][0]['s3']
        bucket_name = s3_event['bucket']['name']
        object_key = s3_event['object']['key']
        s3_file_path = f"s3://{bucket_name}/{object_key}"
        
        # Now you have the S3 file path in the variable 's3_file_path'
        print(f"S3 File Path: {s3_file_path}")
        s3_components = s3_file_path.replace('s3://', '').split('/')

        
        # You can further process the file here or store the path in a variable for later use
        # Your additional code logic goes here


        json_data = {}
        for i, component in enumerate(s3_components):
            column_name = f"column_{i + 1}"
            json_data[column_name] = component

        # Step 2: Create DataFrame using the list of Row objects
            data_row = Row(**json_data)
            df = spark.createDataFrame([data_row])

        # Display the DataFrame
            df.show()

        # Step 3: Select the columns and concatenate the year, month, and day
            df2 = df.select(concat_ws('/',df.column_5, df.column_6, df.column_7).alias("FullName"),
                df.column_2.alias("basefolder"),
                df.column_3.alias("datasettype"),
                df.column_8.alias("filename"))

            df2.show(truncate=False)

            df2.write.mode("append").json("/state2/")


        return {
            'statusCode': 200,
            'body': json.dumps('S3 file path processed successfully.')
        }
    else:
        return {
            'statusCode': 400,
            'body': json.dumps('Invalid event data.')

        }






##################################################### script-2 ###########################################################

#once file loaded into s3 lambda trigger the airflow dag


import boto3
import http.client
import base64
import ast
mwaa_env_name = 'YOUR_ENVIRONMENT_NAME'
dag_name = 'YOUR_DAG_NAME'
mwaa_cli_command = 'dags trigger'
​
client = boto3.client('mwaa')
​
def lambda_handler(event, context):
    # get web token
    mwaa_cli_token = client.create_cli_token(
        Name=mwaa_env_name
    )
    
    conn = http.client.HTTPSConnection(mwaa_cli_token['WebServerHostname'])
    payload = mwaa_cli_command + " " + dag_name
    headers = {
      'Authorization': 'Bearer ' + mwaa_cli_token['CliToken'],
      'Content-Type': 'text/plain'
    }
    conn.request("POST", "/aws_mwaa/cli", payload, headers)
    res = conn.getresponse()
    data = res.read()
    dict_str = data.decode("UTF-8")
    mydata = ast.literal_eval(dict_str)
    return base64.b64decode(mydata['stdout'])

################################################################ script-3 ###########################################################


#lambda trigger the dag the dag runs the Emr serverless



from datetime import datetime, timedelta
from airflow import DAG
from airflow.providers.amazon.aws.operators.emr import EksCreateClusterOperator

 

# Define the default arguments for the DAG

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2023, 7, 20),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),

}

 
# Define the DAG with a unique ID and default arguments

dag = DAG(

    'create_emr_on_eks',
    default_args=default_args,
    schedule_interval=timedelta(days=1),
    catchup=False,

)
 

# EMR on EKS cluster configuration

emr_eks_settings = {

    'name': 'MyEMRCluster',                # Replace with the desired cluster name
    'releaseLabel': 'emr-6.5.0',           # Replace with the desired EMR release version
    'executionRoleArn': 'arn:aws:iam::123456789012:role/MyEMRClusterExecutionRole', # Replace with the IAM role ARN
    'visibleToAllUsers': True,

    # Add any other settings as needed
}

# Create the EMR on EKS cluster

create_emr_on_eks_task = EksCreateClusterOperator(

    task_id='create_emr_on_eks_cluster',
    aws_conn_id='aws_default',  # Replace with your Airflow connection ID for AWS credentials
    eks_cluster_config=emr_eks_settings,
    dag=dag,
)

# Set task dependencies

create_emr_on_eks_task




