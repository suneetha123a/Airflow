#step-1
from airflow import DAG
from datetime import datetime,timedelta
from airflow.operators.dummy_operator import DummyOperator
    

#step-2
default_args={
    'owner':'airflow',
    'depends_on_past':False,
    'start_date':datetime(2020,4,13),
    'retries':0

}
#step-3

def greeting():
    print("helloworld")

dag=DAG(dag_id='testing_dag_email',default_args=default_args,catchup=False,schedule_interval='@once')

#step-4

testing1=DummyOperator(task_id='testing1',dag=dag)
end=DummyOperator(task_id='testing2',dag=dag)

#step -5

testing1 >> end